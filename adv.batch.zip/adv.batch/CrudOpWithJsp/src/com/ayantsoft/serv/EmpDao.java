package com.ayantsoft.serv;
import java.util.*;
import java.sql.*;

public class EmpDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","mysql");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	
	public static int save(Emp e,Address add){//getting the data from user screen wrrapedup in class object
		int status=0;
		
		
		
		try{
			Connection con=EmpDao.getConnection();
			
			PreparedStatement ps1=con.prepareStatement("insert into Address(pin,state,city) values (?,?,?)",Statement.RETURN_GENERATED_KEYS);
			
			
			ps1.setInt(1,add.getPincode());
			
			ps1.setString(2,add.getState());
			ps1.setString(3,add.getCity());
			
			status=ps1.executeUpdate();
			
			int generatedKey = 0;
			
			ResultSet rs = ps1.getGeneratedKeys();//single column
			if (rs.next()) {
			    generatedKey = rs.getInt(1);
			}
			
			PreparedStatement ps=con.prepareStatement("insert into emp(name,password,email,addressId) values (?,?,?,?)");
			ps.setString(1,e.getName());
			ps.setString(2,e.getPassword());
			ps.setString(3,e.getEmail());
			
			ps.setInt(4,generatedKey);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	
	public static int update(Emp e){
		int status=0;
		try{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update emp set name=?,password=?,email=? where id=?");
			ps.setString(1,e.getName());
			ps.setString(2,e.getPassword());
			ps.setString(3,e.getEmail());
			ps.setInt(4,e.getId());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	
	public static int delete(int id){
		int status=0;
		try{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from emp where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	
	public static Emp getEmployeeById(int id){
		Emp e=new Emp();
		
		try{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from emp where id=?");
			ps.setInt(1,id);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()){
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setPassword(rs.getString(3));
				e.setEmail(rs.getString(4));
				
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	
	public static List<Emp> getAllEmployees(){
		List<Emp> list=new ArrayList<Emp>();
		
		try{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from emp INNER JOIN Address ON emp.addressId=Address.id");

			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Emp e=new Emp();
				Address add=new Address();
				
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setPassword(rs.getString(3));
				e.setEmail(rs.getString(4));
				add.setCity(rs.getString("city"));
				add.setPincode(rs.getInt("pin"));
				add.setState(rs.getString("state"));
				e.setAdd(add);
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
