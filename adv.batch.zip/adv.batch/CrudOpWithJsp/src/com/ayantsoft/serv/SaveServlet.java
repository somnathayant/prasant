package com.ayantsoft.serv;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3497529410411926673L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String name=request.getParameter("empName");
		
		String userName=request.getParameter("empName");
		
		String password=request.getParameter("password");
		
		String email=request.getParameter("email");
		
		String state=request.getParameter("state");
		String pin=request.getParameter("pin");
		String city=request.getParameter("city");
	
		
		
		
		Address add=new Address();
		
		add.setPincode(Integer.parseInt(pin));
		add.setState(state);
		add.setCity(city);
		
		
		
		
		Emp e=new Emp();
		
		e.setName(name);
		e.setPassword(password);
		e.setEmail(email);
		
		
			//int status=EmpDao.save(e,add);
		
			int status=EmpDao.save(e,add);//carry the data
			
			
			
			
			
			if(status>0){
				request.setAttribute("result","saved");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
				//request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}else{
				request.setAttribute("result","not");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}
			
			out.close();
		}

}
