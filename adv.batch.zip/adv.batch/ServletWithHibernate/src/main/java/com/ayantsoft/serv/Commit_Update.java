package com.ayantsoft.serv;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Emp;

/**
 * Servlet implementation class Commit_Update
 */
@WebServlet("/Commit_Update")
public class Commit_Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Commit_Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id=Integer.parseInt(request.getParameter("id"));
		Integer addressId=Integer.parseInt(request.getParameter("addressId"));
		
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String city=request.getParameter("city");
		Emp e=new Emp();
		e.setId(id);
		e.setName(name);
		e.setPassword(password);
		e.setEmail(email);
	    Address address=new Address();	
	    address.setId(addressId);
	    address.setCity(city);
	    e.setAddress(address);
			int status=EmpDao.update(e);
			if(status>0){
				request.setAttribute("result","updated");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}else{
				request.setAttribute("result","not");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}
	
	
	}

}
